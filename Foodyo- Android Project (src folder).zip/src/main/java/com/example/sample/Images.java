package com.example.sample;

public class Images {
    //public int url;
    private String rName;
    private String url;

    public Images() {
    }

    public String getrName() {
        return rName;
    }

    public void setrName(String rName) {
        this.rName = rName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
