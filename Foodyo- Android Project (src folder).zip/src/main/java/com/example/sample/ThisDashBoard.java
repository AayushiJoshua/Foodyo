package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.se.omapi.Session;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class ThisDashBoard extends AppCompatActivity {
    Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_this_dash_board);
        logout = (Button) findViewById(R.id.logout);

        SessionManagement sessionManagement = new SessionManagement(ThisDashBoard.this);
        String email = sessionManagement.getSession();

        //Toast.makeText(ThisDashBoard.this, "welcome " + email, Toast.LENGTH_LONG).show();

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Logout();
            }
        });
    }

    private void Logout() {
        SessionManagement sessionManagement = new SessionManagement(ThisDashBoard.this);
        sessionManagement.removeSession();
        FirebaseAuth.getInstance().signOut();
        Toast.makeText(ThisDashBoard.this, "Logged Out Successfully", Toast.LENGTH_SHORT).show();

        MoveToLogin();
    }

    private void MoveToLogin() {
        Intent intent = new Intent(ThisDashBoard.this, Login.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    public void recipe(View v)
    {
        startActivity(new Intent(ThisDashBoard.this, RecipeList_2.class));
    }

    public void feedback(View v)
    {
        startActivity(new Intent(ThisDashBoard.this, Feedback.class));
    }

    public void Ingredients(View v)
    {
        startActivity(new Intent(ThisDashBoard.this, DraweR.class));
    }

}