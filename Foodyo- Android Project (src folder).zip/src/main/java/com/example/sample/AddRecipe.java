package com.example.sample;

import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.sql.Time;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;


public class AddRecipe extends AppCompatActivity {
    EditText recipeName;
    EditText recipeCode;
    EditText timeTaken;
    EditText listOfIngs;
    EditText noOfIngredients;
    EditText ingredientsNAmount;
    EditText recipeSteps;
    EditText videoLink;
    ImageView image;
    Button select, submit;
    Spinner recipeType;
    Uri FilePathUri;
    DatabaseReference databaseReference;
    StorageReference storageReference;
    CollectionReference arrayReference;
    FirebaseFirestore db;
    TextView head;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_recipe);
        recipeName = (EditText) findViewById(R.id.recipeName);
        recipeCode = (EditText) findViewById(R.id.code);
        timeTaken = (EditText) findViewById(R.id.timeTaken);
        listOfIngs = (EditText) findViewById(R.id.arrayOfIng);
        noOfIngredients = (EditText) findViewById(R.id.noOfIngredients);
        ingredientsNAmount = (EditText) findViewById(R.id.ingredientsNAmount);
        recipeSteps = (EditText) findViewById(R.id.steps);
        videoLink = (EditText) findViewById(R.id.link);
        recipeType = (Spinner) findViewById(R.id.recipeType);
        image = (ImageView) findViewById(R.id.image);

        select = (Button) findViewById(R.id.selectImage);
        submit = (Button) findViewById(R.id.submit);
        head = (TextView) findViewById(R.id.heading);

        storageReference = FirebaseStorage.getInstance().getReference("Recipes");
        databaseReference = FirebaseDatabase.getInstance().getReference("Recipes");

        db = FirebaseFirestore.getInstance();
        arrayReference = db.collection("main");

        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Image"), 7);

            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(AddRecipe.this, "Submit Button Clicked!!", Toast.LENGTH_LONG).show();
                InsertRecipeData();
                //loadIngs(head);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 7 && resultCode == RESULT_OK && data != null && data.getData() != null) {

            FilePathUri = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), FilePathUri);
                image.setImageBitmap(bitmap);
            }
            catch (IOException e) {

                e.printStackTrace();
            }
        }
    }




    public String GetFileExtension(Uri uri) {

        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri)) ;

    }





    private void InsertRecipeData() {
        if(FilePathUri != null) {

            //StorageReference reference = storageReference.child("Recipes/" + UUID.randomUUID());
            StorageReference reference = storageReference.child(System.currentTimeMillis() + "." + GetFileExtension(FilePathUri));
            reference.putFile(FilePathUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(AddRecipe.this, "Data Inserted", Toast.LENGTH_LONG).show();
                    String name = recipeName.getText().toString().trim();
                    String code = recipeCode.getText().toString().trim();
                    String time = timeTaken.getText().toString();

                    String ingList = listOfIngs.getText().toString().trim();
                    String[] arrayOfIng = ingList.split("\\s*,\\s*");
                    List<String> ing = Arrays.asList(arrayOfIng);

                    int no_of_ig = Integer.parseInt(noOfIngredients.getText().toString());
                    String type = recipeType.getSelectedItem().toString().trim();
                    String igNAmt = ingredientsNAmount.getText().toString().trim();
                    String steps = recipeSteps.getText().toString().trim();
                    String link = videoLink.getText().toString().trim();
                    @SuppressWarnings("VisibleForTests")
                    RecipeData recipeData = new RecipeData(name, code, time, no_of_ig, type, igNAmt, steps, link, taskSnapshot.getUploadSessionUri().toString(), ing);
                    RecipeData recipeData1 = new RecipeData(name, code, type, ing);
                    String ImageUploadId = databaseReference.push().getKey();
                    databaseReference.child(ImageUploadId).setValue(recipeData).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()) {
                                Toast.makeText(AddRecipe.this, "Data Inserted", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    arrayReference.add(recipeData1);
                }
            });


            //databaseReference = FirebaseDatabase.getInstance().getReference("Recipes");
            //databaseReference.push().setValue(recipeData).addOnCompleteListener(new OnCompleteListener<Void>() {
                //@Override
                //public void onComplete(@NonNull Task<Void> task) {
                    //if (task.isSuccessful()) {
                        //Toast.makeText(AddRecipe.this, "Data Inserted", Toast.LENGTH_LONG).show();
                    //} else {
                        //Toast.makeText(AddRecipe.this, "Some error occurred!!", Toast.LENGTH_LONG).show();
                    //}
                //}
            //});
        } else {
            Toast.makeText(AddRecipe.this, "Some error occurred!!", Toast.LENGTH_LONG).show();
        }


    }




}