package com.example.sample;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RecipeList<ActivityMainBinding> extends AppCompatActivity {
    Switch recipeType;
    ListView recipeList;
    //private FirebaseUser user;
    //private FirebaseDatabase database;
    private DatabaseReference reference;
    //private String userID;
    ArrayList<String> listNames = new ArrayList<>();
    ArrayAdapter<String> adapter;

    //String[] rList;
    ArrayList<String> rImg = new ArrayList<>();
    RecipeData rd;
    ImageView imageView;
    TextView recipeText;
    StorageReference mStorageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_list);
        recipeType = (Switch) findViewById(R.id.vns);
        recipeList = (ListView) findViewById(R.id.listViewRecipe);
        imageView = (ImageView) findViewById(R.id.r_img);
        recipeText = (TextView) findViewById(R.id.r_title);
        rd = new RecipeData();
        Toast.makeText(RecipeList.this, "Select Recipe Type", Toast.LENGTH_LONG).show();


        reference = FirebaseDatabase.getInstance().getReference("Recipes");
        //mStorageReference = FirebaseStorage.getInstance().getReference("Recipes");
        adapter = new ArrayAdapter<String>(this,R.layout.recipelist,R.id.r_title,listNames);

        //CustomRecipe c1=new CustomRecipe(RecipeList.this,listNames,rImg);
        //recipeList.setAdapter(c1);

        recipeType.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b == true) {
                    recipeType.setText("Veg");
                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            //    recipeList.setAdapter(emptyAdapter);
                            listNames.clear();
                            for (DataSnapshot ds : snapshot.getChildren()) {

                                //String link = snapshot.getValue(String.class);
                                //Picasso.get().load(link).into(imageView);
                                // rImg.add(link);
                                //c1.notifyDataSetChanged();
                                rd = ds.getValue(RecipeData.class);
                                if ("veg".equals(rd.type)) {

                                    listNames.add(rd.getrName());
                                    adapter.notifyDataSetChanged();
                                }
                            }

                            recipeList.setAdapter(adapter);


                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(RecipeList.this, "That did not work.", Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    recipeType.setText("Non-Veg");
                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            //    recipeList.setAdapter(emptyAdapter);
                            listNames.clear();
                            for (DataSnapshot ds : snapshot.getChildren()) {

                                //String link = snapshot.getValue(String.class);
                                //Picasso.get().load(link).into(imageView);
                                // rImg.add(link);
                                //c1.notifyDataSetChanged();
                                rd = ds.getValue(RecipeData.class);
                                if ("non-veg".equals(rd.type)) {

                                    listNames.add(rd.getrName());
                                    adapter.notifyDataSetChanged();
                                }
                            }

                            recipeList.setAdapter(adapter);


                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(RecipeList.this, "That did not work.", Toast.LENGTH_LONG).show();
                        }
                    });

                }






            }
        });




        recipeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


        Intent intent = new Intent(RecipeList.this,RecipeDetails.class);
        intent.putExtra("name", listNames.get(i));
        startActivity(intent);

        }
        });





    }
}