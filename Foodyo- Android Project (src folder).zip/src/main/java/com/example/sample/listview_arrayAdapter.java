package com.example.sample;

import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.BreakIterator;
import java.util.ArrayList;

public class listview_arrayAdapter extends ArrayAdapter<CustomAdapter> {

    ArrayList<CustomAdapter> items1;
    static ArrayList<String> checkList = new ArrayList<>();

    public listview_arrayAdapter(@NonNull Context context, int resource, @NonNull ArrayList<CustomAdapter> items) {
        super(context, resource, items);
        this.items1 = items;
    }

    public static ArrayList<String> show() {
        return checkList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.items, parent, false);
        }

        CheckBox checkBox = convertView.findViewById(R.id.item);
        checkBox.setText(items1.get(position).getItem_name());
        if(checkList.contains(items1.get(position).getItem_name())) {
            checkBox.setChecked(true);
        } else if(!checkList.contains(items1.get(position).getItem_name())) {
            checkBox.setChecked(false);
        }
        //checkBox.setText("Hello");

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true && !checkList.contains(checkBox.getText().toString())) {
                    checkList.add(checkBox.getText().toString());
                } else if(isChecked == false){
                    checkList.remove(checkBox.getText().toString());
                }
            }
        });



        return convertView;
    }
}
