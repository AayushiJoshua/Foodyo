package com.example.sample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class RecipeList_2 extends AppCompatActivity implements RecyclerAdapter.OnNoteListener {

    private static final String TAG = "RecipeList_2";

    private DatabaseReference reference;
    private StorageReference mStorageReference;
    private RecyclerView recyclerView;
    private Context mContext = RecipeList_2.this;
    private ArrayList<Images> imagesList;
    private RecyclerAdapter recyclerAdapter;
    Switch recipeType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_list2);
        //Toast.makeText(mContext, "Select Recipe Type", Toast.LENGTH_LONG).show();
        Log.d(TAG, "onCreate: started");
        recipeType = (Switch) findViewById(R.id.vns);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

        reference = FirebaseDatabase.getInstance().getReference("Recipes");
        mStorageReference = FirebaseStorage.getInstance().getReference("Recipes");
        imagesList = new ArrayList<>();
        init();
        recipeType.setText("Veg");

        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                imagesList.clear();
                for(DataSnapshot snapshot1 : snapshot.getChildren()) {
                    if ("veg".equals(snapshot1.child("type").getValue().toString())) {
                        Images images = new Images();
                        images.setUrl(snapshot1.child("imageUrl").getValue().toString());
                        images.setrName(snapshot1.child("rName").getValue().toString());
                        imagesList.add(images);
                    }
                }
                recyclerAdapter = new RecyclerAdapter(mContext,imagesList,RecipeList_2.this);
                recyclerView.setAdapter(recyclerAdapter);
                recyclerAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(RecipeList_2.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        });

    }
    private void init() {
        clearAll();

        //Query query = reference;

        recipeType.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b == true) {
                    recipeType.setText("Veg");

                    reference.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            imagesList.clear();
                            for(DataSnapshot snapshot1 : snapshot.getChildren()) {
                                if ("veg".equals(snapshot1.child("type").getValue().toString())) {
                                    Images images = new Images();
                                    images.setUrl(snapshot1.child("imageUrl").getValue().toString());
                                    images.setrName(snapshot1.child("rName").getValue().toString());
                                    imagesList.add(images);
                                }
                            }
                            recyclerAdapter = new RecyclerAdapter(mContext,imagesList,RecipeList_2.this);
                            recyclerView.setAdapter(recyclerAdapter);
                            recyclerAdapter.notifyDataSetChanged();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(RecipeList_2.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                        }
                    });

                } else {
                    recipeType.setText("Non-Veg");
                    reference.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            imagesList.clear();
                            for(DataSnapshot snapshot1 : snapshot.getChildren()) {
                                if ("non-veg".equals(snapshot1.child("type").getValue().toString())) {
                                    Images images = new Images();
                                    images.setUrl(snapshot1.child("imageUrl").getValue().toString());
                                    images.setrName(snapshot1.child("rName").getValue().toString());
                                    imagesList.add(images);

                                }
                            }
                            recyclerAdapter = new RecyclerAdapter(mContext,imagesList, RecipeList_2.this);
                            recyclerView.setAdapter(recyclerAdapter);
                            recyclerAdapter.notifyDataSetChanged();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(RecipeList_2.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    private void clearAll() {
        if(imagesList != null) {
            imagesList.clear();
            if(recyclerAdapter != null) {
                recyclerAdapter.notifyDataSetChanged();
            }
        }
        imagesList = new ArrayList<>();
    }


    @Override
    public void onNoteClick(int position) {
        Log.d(TAG,"onNoteClicked:clicked.");
        Toast.makeText(mContext, imagesList.get(position).getrName(), Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(RecipeList_2.this, RecipeDetails.class);
        intent.putExtra("name",imagesList.get(position).getrName());
        startActivity(intent);
    }
}