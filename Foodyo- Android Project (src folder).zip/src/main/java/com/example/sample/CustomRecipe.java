package com.example.sample;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.Transaction;
import com.squareup.picasso.Picasso;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Handler;

public class CustomRecipe extends ArrayAdapter {
    private ArrayList<String> r_names;
    private ArrayList<String> img_id;
    private Activity context;
    Bitmap myBitmap;




    CustomRecipe(Activity context, ArrayList<String> r_names, ArrayList<String> img_id) {
        super(context, R.layout.recipelist, r_names);
        this.context=context;
        this.r_names=r_names;
        this.img_id =img_id;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        LayoutInflater inflater = context.getLayoutInflater();

        if (convertView == null)
            v = inflater.inflate(R.layout.recipelist, null, true);
        TextView txt = (TextView) v.findViewById(R.id.r_title);
        ImageView img = (ImageView) v.findViewById(R.id.r_img);

        txt.setText((CharSequence) r_names.get(position));
        //img.setImageResource(Integer.parseInt(String.valueOf(img_id.get(position))));
        //img.setImageURI(Uri.parse(img_id.get(position)));
        //Picasso.get().load(img_id.get(position)).into(img);

        loadImage(img,img_id.get(position));
        return v;

    }
    public void loadImage (View view, String uri){
        class ImageLoadTask extends AsyncTask<Void, Void, Bitmap> {
            private String url;
            private ImageView imageView;

            public ImageLoadTask(String url, ImageView imageView) {
                this.url = url;
                this.imageView = imageView;
            }

            @Override
            protected Bitmap doInBackground(Void... params) {
                try {
                    URL Connection = new URL(url);
                    InputStream input = Connection.openStream();
                    myBitmap = BitmapFactory.decodeStream(input);
                    Bitmap resized = Bitmap.createScaledBitmap(myBitmap, 1000, 1000, true);
                    return resized;

                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(Bitmap result) {
                super.onPostExecute(result);
                imageView.setImageBitmap(result);
            }
        }
        ImageLoadTask obj = new ImageLoadTask(uri, (ImageView) view);
        obj.execute();
    }

}
